function setup() {
  createCanvas(600, 300);
}

function draw() {
  background(90);
  for (let i = 0; i < 50; i++) {

    // random position
    let rx = random(0, width);
    let ry = random(0, height);

    // random color
    let rr = random(0, 255);
    let rg = random(0, 255);
    let rb = random(0, 255);

    fill(rr, rg, rb);
    circle(rx, ry, 100);
  }
}

function keyPressed() {
  if ((key === 'S') || (key === 's')){
    saveCanvas('myCanvas', 'png');
  }
} 
